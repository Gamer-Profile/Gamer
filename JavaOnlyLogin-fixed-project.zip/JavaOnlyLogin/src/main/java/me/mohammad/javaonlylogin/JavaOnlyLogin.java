package me.mohammad.javaonlylogin;

import org.bukkit.plugin.java.JavaPlugin;
import org.geysermc.floodgate.api.FloodgateApi;

public class JavaOnlyLogin extends JavaPlugin {
    @Override
    public void onEnable() {
        FloodgateApi floodgate = FloodgateApi.api();
        getServer().getPluginManager().registerEvents(new LoginListener(this, floodgate), this);
        getLogger().info("JavaOnlyLogin enabled!");
    }
}
