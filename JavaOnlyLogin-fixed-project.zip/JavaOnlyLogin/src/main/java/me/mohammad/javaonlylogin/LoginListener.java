package me.mohammad.javaonlylogin;

import fr.xephi.authme.api.v3.AuthMeApi;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.geysermc.floodgate.api.FloodgateApi;

import java.util.UUID;

public class LoginListener implements Listener {
    private final JavaOnlyLogin plugin;
    private final FloodgateApi floodgate;

    public LoginListener(JavaOnlyLogin plugin, FloodgateApi floodgate) {
        this.plugin = plugin;
        this.floodgate = floodgate;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onJoin(PlayerJoinEvent event) {
        if (!floodgate.isFloodgatePlayer(event.getPlayer().getUniqueId())) {
            return; // Java player: AuthMe handles /register and /login normally.
        }

        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            AuthMeApi authMe = AuthMeApi.getInstance();
            if (authMe == null || !event.getPlayer().isOnline()) {
                return;
            }

            if (authMe.isAuthenticated(event.getPlayer())) {
                return;
            }

            // Bedrock players never need to type /register or /login.
            // If AuthMe has no account yet, create one with a random password and
            // authenticate it immediately. Otherwise, just force-login the account.
            if (!authMe.isRegistered(event.getPlayer().getName())) {
                authMe.forceRegister(event.getPlayer(), UUID.randomUUID().toString(), true);
            } else {
                authMe.forceLogin(event.getPlayer());
            }
        }, 1L);
    }
}
